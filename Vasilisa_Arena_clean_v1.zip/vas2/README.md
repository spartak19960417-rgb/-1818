# Василиса — Arena Android wrapper

Android WebView wrapper for https://arena.ai/ with Russian branding, splash screen, file uploads, cookies, and basic UI localization.

GitHub Actions workflow should be placed in `.github/workflows/build.yml`.
