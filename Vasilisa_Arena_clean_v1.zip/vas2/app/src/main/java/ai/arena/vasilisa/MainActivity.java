package ai.arena.vasilisa;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.webkit.CookieManager;
import android.webkit.JsResult;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final String URL = "https://arena.ai/";
    private static final int FILE_REQUEST = 1001;
    private WebView webView;
    private View splash;
    private ValueCallback<Uri[]> fileCallback;
    private SharedPreferences prefs;

    @SuppressLint("SetJavaScriptEnabled")
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_main);
        FrameLayout root = findViewById(R.id.root);
        splash = findViewById(R.id.splash);
        webView = findViewById(R.id.webview);
        prefs = getSharedPreferences("vasilisa", MODE_PRIVATE);
        applyBars(prefs.getBoolean("dark", true));

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportZoom(false);

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(webView, true);

        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) { return false; }
            @Override public boolean shouldOverrideUrlLoading(WebView v, String url) { return false; }
            @Override public void onPageFinished(WebView v, String url) {
                injectUI();
                splash.postDelayed(() -> hideSplash(), 500);
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onJsAlert(WebView v, String url, String msg, JsResult result) { return super.onJsAlert(v,url,msg,result); }
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try { startActivityForResult(params.createIntent(), FILE_REQUEST); }
                catch (Exception e) { fileCallback = null; Toast.makeText(MainActivity.this,"Не удалось открыть выбор файла",Toast.LENGTH_SHORT).show(); return false; }
                return true;
            }
        });
        if (state == null) webView.loadUrl(URL); else { webView.restoreState(state); splash.postDelayed(() -> hideSplash(), 700); }
    }

    private void injectUI() {
        boolean dark = prefs.getBoolean("dark", true);
        String d = dark ? "dark" : "light";
        String js = "javascript:(function(){"
            + "document.title='Василиса';"
            + "if(document.getElementById('vasilisa-style'))return;"
            + "var st=document.createElement('style');st.id='vasilisa-style';st.textContent=`"
            + "html,body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif!important;}"
            + "button{border-radius:14px!important;transition:transform .15s ease,box-shadow .15s ease!important;}button:active{transform:scale(.97)!important;}"
            + "input,textarea{border-radius:16px!important;}"
            + "html.vasilisa-dark body{background:#0b1020!important;color:#eef2ff!important;}"
            + "html.vasilisa-light body{background:#f7f8fc!important;color:#182033!important;}"
            + "html.vasilisa-dark [class*='bg-white'],html.vasilisa-dark [class*='bg-gray-50'],html.vasilisa-dark [class*='bg-gray-100']{background-color:#12182a!important;}"
            + "html.vasilisa-dark [class*='border-gray'],html.vasilisa-dark [class*='border-slate']{border-color:rgba(148,163,184,.18)!important;}"
            + "`;document.head.appendChild(st);"
            + "document.documentElement.classList.add('vasilisa-" + d + "');"
            + "var map={'Arena':'Василиса','Battle Mode':'Режим битвы','Select':'Выбрать','Get started':'Начать','Settings':'Настройки','New chat':'Новый чат','Sign in':'Войти','Sign up':'Регистрация','Login':'Войти','Logout':'Выйти','Send':'Отправить','Share':'Поделиться','Copy':'Копировать','Delete':'Удалить','Edit':'Изменить','Cancel':'Отмена','Save':'Сохранить','Upload':'Загрузить','Attach':'Прикрепить','Retry':'Повторить','Stop':'Остановить','Search':'Поиск','Menu':'Меню','Close':'Закрыть','Theme':'Тема','Language':'Язык','Light':'Светлая','Dark':'Тёмная'};"
            + "function tr(){var w=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);var n;while(n=w.nextNode()){var p=n.parentElement;if(!p||/SCRIPT|STYLE|TEXTAREA|CODE|PRE/.test(p.tagName))continue;var t=n.nodeValue.trim();if(map[t])n.nodeValue=n.nodeValue.replace(t,map[t]);}document.querySelectorAll('[placeholder]').forEach(function(e){if(map[e.placeholder])e.placeholder=map[e.placeholder];});document.querySelectorAll('[aria-label]').forEach(function(e){if(map[e.getAttribute('aria-label')])e.setAttribute('aria-label',map[e.getAttribute('aria-label')]);});}tr();"
            + "new MutationObserver(function(){tr();}).observe(document.body,{childList:true,subtree:true});"
            + "})();void(0);";
        webView.evaluateJavascript(js,null);
    }

    private void hideSplash() {
        if (splash == null || splash.getVisibility()!=View.VISIBLE) return;
        AlphaAnimation a = new AlphaAnimation(1f,0f); a.setDuration(350); a.setFillAfter(true);
        a.setAnimationListener(new android.view.animation.Animation.AnimationListener(){
            public void onAnimationStart(android.view.animation.Animation x){} public void onAnimationRepeat(android.view.animation.Animation x){}
            public void onAnimationEnd(android.view.animation.Animation x){splash.setVisibility(View.GONE);}
        }); splash.startAnimation(a);
    }

    private void applyBars(boolean dark) {
        int c = dark ? Color.rgb(11,16,32) : Color.WHITE;
        getWindow().setStatusBarColor(c); getWindow().setNavigationBarColor(c);
        getWindow().getDecorView().setSystemUiVisibility(dark ? 0 : View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode!=FILE_REQUEST || fileCallback==null)return;
        Uri[] result=null;
        if(resultCode==RESULT_OK && data!=null){
            if(data.getClipData()!=null){int n=data.getClipData().getItemCount(); result=new Uri[n]; for(int i=0;i<n;i++) result[i]=data.getClipData().getItemAt(i).getUri();}
            else if(data.getData()!=null) result=new Uri[]{data.getData()};
        }
        fileCallback.onReceiveValue(result); fileCallback=null;
    }

    @Override protected void onSaveInstanceState(Bundle out){ super.onSaveInstanceState(out); webView.saveState(out); }
    @Override public void onBackPressed(){ if(webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
}
